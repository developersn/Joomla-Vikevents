<?php
defined('_JEXEC') or die();

if(!defined('DS'))
{
    define('DS',DIRECTORY_SEPARATOR);
}

class plgSystemSn_vikevents extends JPlugin
{
	function __construct(& $subject, $config) 
	{
		parent::__construct($subject, $config);
	}
}