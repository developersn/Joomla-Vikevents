<?php
defined('_JEXEC') OR die('Restricted Area');

jimport('sncore.include');

class vikEventsPayment {
	
	private $orderInfo;

    public function __construct ($order, $params = array())
    {
        $this->orderInfo = $order;
        $this->params = $params;

        SNGlobal::loadLanguage('plg_system_sn_vikevents',JPATH_ADMINISTRATOR);
    }

	static function getAdminParameters () {

        SNGlobal::loadLanguage('plg_system_sn_vikevents',JPATH_ADMINISTRATOR);

        return array(
            'sn_pin' => array(
                'type' => 'text',
                'label' => JText::_('SN_FIELD_PIN')
            ),
            'sn_currency' => array(
                'type' => 'select',
                'label' => JText::_('SN_FIELD_CURRENCY'),
                'options' => array(
                    'Rial',
                    'Toman'
                ),
            ),
            'sn_send_payer_info' => array(
                'type' => 'select',
                'label' => JText::_('SN_FIELD_SEND_PAYER_INFO'),
                'options' => array(
                    'Enable',
                    'Disable'
                ),
            ),
        );
	}

	
	public function showPayment()
    {
        $app = JFactory::getApplication();

        $orderInfo = $this->orderInfo;
        $amount = $orderInfo['order_total'];

        if($amount > 0)
        {
            $backUrl = $orderInfo['notify_url'];
            $cancelUrl = $orderInfo['return_url'];
            $orderId = $orderInfo['order']['id'];
            $email = !empty($orderInfo['order']['purchemail']) ? $orderInfo['order']['purchemail'] : '';

            $pin = !empty($this->params['sn_pin']) ? $this->params['sn_pin'] : '';
            $currency = !empty($this->params['sn_currency']) ? $this->params['sn_currency'] : 1;
            $currency = $currency == 'Rial' ? 1 : 0;
            $sendPayerInfo = !empty($this->params['sn_send_payer_info']) ? $this->params['sn_send_payer_info'] : 1;
            $sendPayerInfo = $sendPayerInfo == 'Enable' ? 1 : 0;

            $amount = SNApi::modifyPrice($amount, $currency);

            $data = array(
                'pin' => $pin,
                'price' => $amount,
                'callback' => $backUrl,
                'order_id' => $orderId,
                'email' => $email,
                'description' => '',
                'mobile' => '',
                'main_price' => $amount,
            );

            list($status, $msg, $resultData) = SNApi::request($data, $sendPayerInfo, 'vikevents');

            if ($status == true) {
                $data['bank_callback_details'] = $resultData['bank_callback_details'];
                $data['au'] = $resultData['au'];

                SNApi::clearData();
                SNApi::setData($data);

                $html = '<form action="' . $resultData['form_details']['action'] . '" method="post">';
                foreach ($resultData['form_details']['fields'] as $key => $value) {
                    $html .= '<input type="hidden" name="' . $key . '" value="' . $value . '" />';
                }
                $html .= '<input type="submit" name="submit" class="vevinputbox sn-vikevents-paid-btn" value="' . JText::_('SN_PAY') . '" />';
                $html .= '<div style="clear: both;"></div>';
                $html .= '</form>';

                echo $html;
                return false;
            }
        }

        $msg = JText::_('SN_UNPAID_TRANSACTION');
        $app->enqueueMessage('<h5>'.$msg.'</h5>','Error');
	}
	
	public function validatePayment()
    {
        $app = JFactory::getApplication();

        $orderInfo = $this->orderInfo;
        $orderId = $orderInfo['id'];
        $au = SNGlobal::getVar('au','','none','request');
        $sessionData = SNApi::getData();

        if(!empty($orderId) && !empty($au) && !empty($sessionData) && $sessionData['order_id'] == $orderId)
        {
            $bankData = array();
            foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
            {
                $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
            }

            $data = array (
                'pin' => $sessionData['pin'],
                'price' => $sessionData['price'],
                'order_id' => $sessionData['order_id'],
                'au' => $au,
                'bank_return' => $bankData,
            );

            list($status,$msg,$resultData) = SNApi::verify($data,'vikevents');

            if($status == true)
            {
                $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;

                $successMsg = JText::_('SN_PAID_TRANSACTION');
                $successMsg = str_replace('{REF}',$bankAu,$successMsg);

                $result = array(
                    'log' => $successMsg,
                    'verified' => 1,
                    'tot_paid' => $sessionData['main_price'],
                );

                $app->enqueueMessage('<h5>'.$successMsg.'</h5>','message');
                return $result;
            }
        }

        $errorMsg = JText::_('SN_UNPAID_TRANSACTION');
        $result = array(
            'log' => $errorMsg,
            'verified' => 0,
        );

        $app->enqueueMessage('<h5>'.$errorMsg.'</h5>','error');
        return $result;
	}
	
}


?>